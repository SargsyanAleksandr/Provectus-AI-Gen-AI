"""
Streaming JSONL → SQLite ingestion pipeline.
Handles 500MB+ files in constant ~50MB RAM using batched inserts.
"""
import json, sqlite3, csv, logging
from pathlib import Path
from datetime import date

log = logging.getLogger(__name__)
DB_PATH = Path(__file__).parent.parent / "data" / "analytics.db"

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type    TEXT NOT NULL,
    ts            TEXT NOT NULL,
    email         TEXT,
    session_id    TEXT,
    model         TEXT,
    cost          REAL DEFAULT 0,
    inp_tokens    INTEGER DEFAULT 0,
    out_tokens    INTEGER DEFAULT 0,
    cache_tokens  INTEGER DEFAULT 0,
    duration_ms   REAL DEFAULT 0,
    tool          TEXT,
    decision      TEXT,
    success       TEXT,
    prompt_len    INTEGER DEFAULT 0,
    terminal      TEXT,
    hour          INTEGER,
    ds            TEXT,
    dow           TEXT
);
CREATE TABLE IF NOT EXISTS employees (
    email TEXT PRIMARY KEY,
    full_name TEXT, practice TEXT, level TEXT, location TEXT
);
CREATE INDEX IF NOT EXISTS ix_type    ON events(event_type);
CREATE INDEX IF NOT EXISTS ix_email   ON events(email);
CREATE INDEX IF NOT EXISTS ix_session ON events(session_id);
CREATE INDEX IF NOT EXISTS ix_ds      ON events(ds);
CREATE INDEX IF NOT EXISTS ix_model   ON events(model);
CREATE INDEX IF NOT EXISTS ix_tool    ON events(tool);
"""

_DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

def _parse(msg: dict):
    a   = msg.get("attributes", {})
    ts  = a.get("event.timestamp", "")
    if not ts:
        return None
    try:
        hour = int(ts[11:13])
        ds   = ts[:10]
        dow  = _DAYS[date.fromisoformat(ds).weekday()]
    except Exception:
        hour, ds, dow = 0, "", ""
    return (
        msg.get("body",""), ts,
        a.get("user.email",""), a.get("session.id",""), a.get("model",""),
        float(a.get("cost_usd",0) or 0),
        int(a.get("input_tokens",0) or 0),
        int(a.get("output_tokens",0) or 0),
        int(a.get("cache_read_tokens",0) or 0),
        float(a.get("duration_ms",0) or 0),
        a.get("tool_name",""), a.get("decision",""), a.get("success",""),
        int(a.get("prompt_length",0) or 0),
        a.get("terminal.type",""),
        hour, ds, dow,
    )

_INSERT = """
INSERT INTO events
(event_type,ts,email,session_id,model,cost,inp_tokens,out_tokens,
 cache_tokens,duration_ms,tool,decision,success,prompt_len,terminal,hour,ds,dow)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
"""

def ingest(jsonl_path: str, csv_path: str, db_path: str = str(DB_PATH), batch: int = 5000) -> dict:
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    conn.commit()

    if conn.execute("SELECT COUNT(*) FROM events").fetchone()[0] > 0:
        n = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        conn.close()
        return {"events": n, "skipped": True}

    # Load employees
    with open(csv_path, newline="") as f:
        emp_rows = [(r["email"],r["full_name"],r["practice"],r["level"],r["location"])
                    for r in csv.DictReader(f)]
    conn.executemany("INSERT OR REPLACE INTO employees VALUES (?,?,?,?,?)", emp_rows)

    # Stream events in batches
    total, buf = 0, []
    with open(jsonl_path) as f:
        for line in f:
            try:
                batch_obj = json.loads(line)
            except Exception:
                continue
            for ev in batch_obj.get("logEvents", []):
                try:
                    row = _parse(json.loads(ev["message"]))
                    if row:
                        buf.append(row)
                except Exception:
                    continue
            if len(buf) >= batch:
                conn.executemany(_INSERT, buf)
                conn.commit()
                total += len(buf)
                buf = []
                log.info(f"Ingested {total:,}…")
    if buf:
        conn.executemany(_INSERT, buf)
        conn.commit()
        total += len(buf)

    conn.close()
    log.info(f"Complete: {total:,} events")
    return {"events": total, "employees": len(emp_rows)}
