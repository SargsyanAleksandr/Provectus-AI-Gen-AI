"""SQL analytics queries → pandas DataFrames."""
import sqlite3, pandas as pd
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "data" / "analytics.db"

def get_conn(db: str = str(DB_PATH)) -> sqlite3.Connection:
    c = sqlite3.connect(db)
    c.row_factory = sqlite3.Row
    return c

def q(conn, sql, p=()):
    return pd.read_sql_query(sql, conn, params=p)

def kpis(conn):
    r = conn.execute("""
        SELECT
          SUM(CASE WHEN event_type='claude_code.api_request' THEN cost ELSE 0 END) AS total_cost,
          SUM(CASE WHEN event_type='claude_code.api_request' THEN 1 ELSE 0 END) AS total_requests,
          SUM(CASE WHEN event_type='claude_code.api_error' THEN 1 ELSE 0 END) AS total_errors,
          COUNT(DISTINCT session_id) AS total_sessions,
          COUNT(DISTINCT email) AS total_users,
          COUNT(*) AS total_events
        FROM events""").fetchone()
    d = dict(r)
    d["error_rate"] = round(d["total_errors"] / max(d["total_requests"],1)*100, 2)
    return d

def daily_cost(conn):
    return q(conn, """
        SELECT ds, SUM(cost) AS cost, COUNT(*) AS requests
        FROM events WHERE event_type='claude_code.api_request' AND ds!=''
        GROUP BY ds ORDER BY ds""")

def hourly(conn):
    return q(conn, """
        SELECT hour, COUNT(*) AS requests, SUM(cost) AS cost
        FROM events WHERE event_type='claude_code.api_request'
        GROUP BY hour ORDER BY hour""")

def model_stats(conn):
    return q(conn, """
        SELECT model, COUNT(*) AS requests, SUM(cost) AS total_cost,
               AVG(cost) AS avg_cost, AVG(inp_tokens) AS avg_inp,
               AVG(out_tokens) AS avg_out, AVG(cache_tokens) AS avg_cache,
               AVG(duration_ms) AS avg_dur
        FROM events WHERE event_type='claude_code.api_request' AND model!=''
        GROUP BY model ORDER BY total_cost DESC""")

def tool_stats(conn):
    return q(conn, """
        SELECT d.tool,
               COUNT(*) AS total,
               SUM(CASE WHEN d.decision='accept' THEN 1 ELSE 0 END) AS accepted,
               AVG(CASE WHEN r.success='true' THEN 1.0 ELSE 0.0 END) AS success_rate,
               AVG(r.duration_ms) AS avg_dur
        FROM events d
        LEFT JOIN events r ON r.session_id=d.session_id
            AND r.tool=d.tool AND r.event_type='claude_code.tool_result'
        WHERE d.event_type='claude_code.tool_decision' AND d.tool!=''
        GROUP BY d.tool ORDER BY total DESC""")

def practice_stats(conn):
    return q(conn, """
        SELECT e.practice, COUNT(DISTINCT ev.email) AS users,
               SUM(ev.cost) AS cost, COUNT(*) AS requests
        FROM events ev JOIN employees e ON e.email=ev.email
        WHERE ev.event_type='claude_code.api_request'
        GROUP BY e.practice ORDER BY cost DESC""")

def top_users(conn, n=15):
    return q(conn, f"""
        SELECT ev.email, e.full_name, e.practice, e.level, e.location,
               SUM(ev.cost) AS cost, COUNT(DISTINCT ev.session_id) AS sessions,
               COUNT(*) AS requests
        FROM events ev JOIN employees e ON e.email=ev.email
        WHERE ev.event_type='claude_code.api_request'
        GROUP BY ev.email ORDER BY cost DESC LIMIT {n}""")
