"""
ML Analytics Engine
- Polynomial cost forecasting with 95% CI
- Dual-method anomaly detection (Z-score + IQR)
- Behavioral user segmentation
- Token efficiency scoring
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass


@dataclass
class Forecast:
    dates:       list
    values:      list
    upper:       list
    lower:       list
    r2:          float
    trend:       str
    trend_pct:   float
    resid_std:   float


def forecast_cost(daily_df: pd.DataFrame, horizon: int = 14) -> Forecast:
    """Polynomial regression (degree 2) forecast with residual-based 95% CI."""
    # Accept either 'ds' or 'date' column
    date_col = "ds" if "ds" in daily_df.columns else "date"
    df = daily_df[daily_df[date_col].str.len() == 10].sort_values(date_col).copy()

    x = np.arange(len(df))
    y = df["cost"].values.astype(float)

    coeffs    = np.polyfit(x, y, 2)
    poly      = np.poly1d(coeffs)
    y_hat     = poly(x)
    ss_res    = np.sum((y - y_hat) ** 2)
    ss_tot    = np.sum((y - y.mean()) ** 2)
    r2        = float(max(0.0, 1 - ss_res / max(ss_tot, 1e-9)))
    resid_std = float(np.std(y - y_hat))

    last_date = datetime.strptime(df[date_col].iloc[-1], "%Y-%m-%d")
    fx        = np.arange(len(df), len(df) + horizon)
    fdates    = [(last_date + timedelta(days=i+1)).strftime("%Y-%m-%d") for i in range(horizon)]
    fv        = poly(fx)

    cur_avg   = float(np.mean(y[-7:]))
    fut_avg   = float(np.mean(fv))
    pct       = (fut_avg - cur_avg) / max(cur_avg, 1e-9) * 100

    return Forecast(
        dates      = fdates,
        values     = [round(float(v), 2) for v in fv],
        upper      = [round(float(v + 1.96 * resid_std), 2) for v in fv],
        lower      = [round(float(max(v - 1.96 * resid_std, 0)), 2) for v in fv],
        r2         = round(r2, 3),
        trend      = "rising" if pct > 5 else ("falling" if pct < -5 else "stable"),
        trend_pct  = round(pct, 1),
        resid_std  = round(resid_std, 2),
    )


@dataclass
class Anomaly:
    date:     str
    cost:     float
    z:        float
    iqr_flag: bool
    severity: str   # "high" | "medium"


def detect_anomalies(daily_df: pd.DataFrame) -> list:
    """Z-score (|z|>2) + IQR method. Either triggers a flag."""
    date_col = "ds" if "ds" in daily_df.columns else "date"
    df = daily_df[daily_df[date_col].str.len() == 10].copy()
    y  = df["cost"].values.astype(float)

    mu, sigma = y.mean(), y.std()
    q1, q3    = np.percentile(y, 25), np.percentile(y, 75)
    iqr       = q3 - q1
    lo, hi    = q1 - 1.5 * iqr, q3 + 1.5 * iqr

    results = []
    for _, row in df.iterrows():
        z    = float((row["cost"] - mu) / max(sigma, 1e-9))
        iqr_ = bool(row["cost"] < lo or row["cost"] > hi)
        if abs(z) > 2.0 or iqr_:
            results.append(Anomaly(
                date     = str(row[date_col]),
                cost     = round(float(row["cost"]), 2),
                z        = round(z, 2),
                iqr_flag = iqr_,
                severity = "high" if abs(z) > 3 else "medium",
            ))
    return sorted(results, key=lambda a: abs(a.z), reverse=True)


def segment_users(df: pd.DataFrame) -> pd.DataFrame:
    """Percentile-based 3-tier segmentation: Light / Power / Heavy User."""
    out = df.copy()
    cost_col = "cost" if "cost" in out.columns else "total_cost"
    p33 = out[cost_col].quantile(0.33)
    p66 = out[cost_col].quantile(0.66)
    out["segment"] = out[cost_col].apply(
        lambda c: "Heavy User" if c >= p66 else ("Power User" if c >= p33 else "Light User")
    )
    return out


def user_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    cost_col = "cost" if "cost" in df.columns else "total_cost"
    c  = df[cost_col].values.astype(float)
    mu, std = c.mean(), c.std()
    out = df.copy()
    out["user_z"]       = (c - mu) / max(std, 1e-9)
    out["user_anomaly"] = out["user_z"] > 2.0
    return out


def token_efficiency(model_df: pd.DataFrame) -> pd.DataFrame:
    df = model_df.copy()
    inp_col   = "avg_inp"   if "avg_inp"   in df.columns else "avg_input"
    out_col   = "avg_out"   if "avg_out"   in df.columns else "avg_output"
    cache_col = "avg_cache" if "avg_cache" in df.columns else "avg_cache"
    df["efficiency"] = df[out_col] / (df[inp_col] + df[cache_col] + 1)
    mx = df["efficiency"].max()
    df["efficiency_pct"] = (df["efficiency"] / max(mx, 1e-9) * 100).round(1)
    return df
