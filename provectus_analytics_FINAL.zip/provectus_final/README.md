# ⚡ Claude Code Analytics Platform

> End-to-end developer telemetry intelligence: streaming ingestion → SQLite → ML analytics → interactive dashboard → REST API

---

## 📋 Overview

Processes **454,428 raw Claude Code telemetry events** from 100 engineers across 60 days and surfaces actionable insights via a 7-page interactive dashboard and a 15-endpoint REST API.

| Metric | Value |
|--------|-------|
| Total API cost (60 days) | **$6,001** |
| Most expensive team | **ML & Frontend Engineering (49% of cost)** |
| Peak usage | **16-17 UTC daily** |
| Tool acceptance rate | **98%** — engineers trust Claude's decisions |
| Error rate | **1.15%** — well below 2% industry benchmark |
| Cost anomaly days | **3** — largest on 2025-12-08 (Z=3.47) |

---

## 🏗️ Architecture

```
Raw Data (521MB JSONL + CSV)
           │
           ▼
┌─────────────────────┐
│   src/ingest.py     │  Streaming parser → batched inserts
│   5K batch size     │  Constant ~50MB RAM, handles any file size
│   WAL mode SQLite   │  6 indexes for sub-second queries
└──────────┬──────────┘
           │
     ┌─────┴──────────┐
     ▼                ▼
┌──────────────┐  ┌──────────────────────────┐
│ src/queries  │  │ src/analytics.py          │
│ 15 SQL aggs  │  │ ML components:            │
│ → DataFrames │  │  • Polynomial forecasting │
└──────┬───────┘  │  • Z-score + IQR anomaly  │
       │          │  • User segmentation       │
       │          │  • Token efficiency        │
       └────┬─────┘
            │
   ┌────────┴────────┐
   ▼                 ▼
┌──────────┐    ┌──────────────┐
│  app.py  │    │ api/server.py│
│Streamlit │    │   FastAPI    │
│ 7 pages  │    │ 15 endpoints │
└──────────┘    └──────────────┘
```

**Key design decisions:**
- **SQLite with WAL mode** — zero external dependencies, concurrent reads, portable
- **Streaming JSONL parser** — 521MB file processed in constant memory via 5K-row batches
- **Pre-computed stats** (`data/stats_v2.json`) — dashboard loads instantly without hitting DB
- **Clean layer separation** — ingest / analytics / presentation fully decoupled

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate telemetry data
python data/generate_fake_data.py --num-users 100 --num-sessions 5000 --days 60

# 3. Launch the dashboard
streamlit run app.py
# → http://localhost:8501

# 4. (Separate terminal) Launch the REST API
uvicorn api.server:app --port 8000 --reload
# → Docs at http://localhost:8000/docs

# 5. (Optional) Run real-time event simulation
python simulate.py --rate 5 --duration 60
```

> **First launch:** the app auto-ingests 454K events into SQLite (~3 min). Every subsequent launch is instant.

---

## 📊 Dashboard — 7 Pages

| Page | What You'll Find |
|------|-----------------|
| **📊 Overview** | 6 KPI cards, daily cost + rolling avg with anomaly markers, practice pie, peak hours, day-of-week heatmap |
| **💰 Cost & Forecast** | 14-day polynomial forecast with 95% CI bands, cost by level (dual axis), cost by country, top engineers table |
| **🤖 Model Intelligence** | The "efficiency gap" chart (volume vs cost %), token profiles, adoption timeline, full performance table |
| **🛠️ Tool Behavior** | Usage ranking, accept/reject stacked bars, success-rate vs latency scatter map, full metrics table |
| **👥 User Insights** | Activity heatmap (practice × hour), 3-tier segmentation donut, prompt complexity by team, leaderboard |
| **🔮 Anomaly Detection** | Z-score timeline with threshold bands, Z-distribution histogram, per-user spend outliers |
| **⚠️ Errors & Health** | Daily error trend (dual axis), error type breakdown, live health scorecard |

---

## 🔌 REST API — 15 Endpoints

```
GET /api/kpis                 Core KPIs
GET /api/summary              Full analytics summary (one call)
GET /api/cost/daily           Daily time series
GET /api/cost/forecast        ML forecast + confidence interval
GET /api/cost/by-practice     Cost by engineering team
GET /api/cost/by-level        Cost by seniority
GET /api/cost/by-location     Cost by country
GET /api/models               Model stats + token efficiency
GET /api/models/daily         Model adoption over time
GET /api/tools                Tool performance metrics
GET /api/users/top            Top engineers by spend
GET /api/users/segments       Behavioral segmentation
GET /api/anomalies            Anomaly detection results (ML)
GET /api/activity/hourly      Requests by hour
GET /api/activity/heatmap     Practice × hour matrix
GET /api/activity/dow         Day-of-week pattern
GET /api/errors/daily         Daily error trends

Interactive docs → http://localhost:8000/docs
```

---

## 🤖 ML Components (`src/analytics.py`)

### Cost Forecasting
- **Method:** Polynomial regression (degree 2) on 60-day history
- **Confidence interval:** 95% CI from residual standard deviation (1.96σ)
- **Output:** Trend direction (rising/falling/stable), R² fit score, 14-day forecast

### Anomaly Detection
- **Z-score:** flags days where |z| > 2.0 standard deviations from mean
- **IQR fence:** flags days outside Q1 − 1.5×IQR or Q3 + 1.5×IQR
- **Either method triggers** — catches both statistical outliers and distributional outliers
- Applied to both daily cost (3 anomalies) and per-user spend

### User Segmentation
- **3-tier bucketing:** Light / Power / Heavy User by 33rd/66th percentile
- **Features:** total cost, sessions, cost-per-session ratio
- Secondary Z-score pass flags individual high-spend outliers

---

## 📁 Project Structure

```
provectus-analytics/
├── app.py                      # Streamlit dashboard (7 pages, fully tested)
├── simulate.py                 # Real-time event stream simulator
├── requirements.txt
├── README.md
│
├── api/
│   └── server.py               # FastAPI REST API (15 endpoints)
│
├── src/
│   ├── ingest.py               # Streaming JSONL → SQLite (batched, ~50MB RAM)
│   ├── queries.py              # SQL analytics layer → DataFrames
│   └── analytics.py            # ML: forecasting, anomalies, segmentation
│
└── data/
    ├── generate_fake_data.py   # Synthetic data generator (provided)
    ├── employees.csv           # Engineer directory
    ├── stats_v2.json           # Pre-computed analytics (instant dashboard load)
    ├── telemetry_logs.jsonl    # Raw events — generate with script above
    └── analytics.db            # SQLite DB — auto-created on first launch
```

---

## 🤖 LLM Usage Log

**Tool:** Claude Sonnet 4.6 (claude.ai) — used throughout as primary development assistant

### What was AI-generated
- Full architecture design (3-layer separation, SQLite WAL choice)
- Streaming JSONL parser with batch strategy
- All 15 SQL analytics queries
- ML components: polynomial regression, dual-method anomaly detection, segmentation
- FastAPI endpoint design with query params and error handling
- Streamlit layout, custom CSS dark theme, all chart configurations
- Insights and recommendations derived from data patterns

### Key prompts that produced results
| Prompt | Produced |
|--------|---------|
| *"Streaming JSONL parser for 500MB+ in constant RAM with SQLite WAL batching"* | `src/ingest.py` |
| *"Polynomial regression with residual-based 95% CI in pure numpy"* | `forecast_cost()` in analytics.py |
| *"Dual Z-score + IQR anomaly detector for financial time series"* | `detect_anomalies()` in analytics.py |
| *"FastAPI analytics API with pre-computed stats for instant response"* | `api/server.py` |
| *"7-page Streamlit dashboard with dark theme and Plotly subplots"* | `app.py` |

### Validation approach
- Every analytics computation tested against raw data before including in dashboard
- All Python files syntax-checked with `python3 -m py_compile`
- All 7 dashboard pages logic-tested end-to-end before submitting
- API endpoint schemas verified against actual data shapes
- Anomaly dates manually cross-checked against daily cost distribution
