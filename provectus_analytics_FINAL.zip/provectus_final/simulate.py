"""
Real-Time Event Simulator
Writes live Claude Code events to SQLite, demonstrating streaming ingestion.

Usage:
    python simulate.py --rate 5 --duration 60
"""
import argparse, json, random, sqlite3, time, uuid
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "analytics.db"
DAYS    = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
MODELS  = ["claude-haiku-4-5-20251001","claude-opus-4-6","claude-sonnet-4-6"]
TOOLS   = ["Read","Bash","Edit","Grep","Write","Glob","TodoWrite"]
EVENTS  = ["claude_code.api_request","claude_code.tool_decision",
           "claude_code.tool_result","claude_code.user_prompt"]
COSTS   = {"claude-haiku-4-5-20251001":0.003,"claude-opus-4-6":0.07,"claude-sonnet-4-6":0.05}

INSERT = """INSERT INTO events
(event_type,ts,email,session_id,model,cost,inp_tokens,out_tokens,
 cache_tokens,duration_ms,tool,decision,success,prompt_len,terminal,hour,ds,dow)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""

def simulate(rate: int = 5, duration: int = 30):
    if not DB_PATH.exists():
        print(f"DB not found at {DB_PATH}. Run: streamlit run app.py first.")
        return

    conn = sqlite3.connect(str(DB_PATH))
    emails = [r[0] for r in conn.execute("SELECT email FROM employees").fetchall()]
    if not emails:
        print("No employees found — run data ingestion first.")
        conn.close()
        return

    interval = 1.0 / max(rate, 1)
    total, t0 = 0, time.time()
    print(f"▶  Streaming {rate} events/sec for {duration}s → {DB_PATH.name}")

    try:
        while time.time() - t0 < duration:
            now   = datetime.now(timezone.utc)
            etype = random.choice(EVENTS)
            model = random.choice(MODELS) if etype == "claude_code.api_request" else ""
            cost  = max(0, random.gauss(COSTS.get(model, 0), 0.005)) if model else 0.0
            tool  = random.choice(TOOLS) if "tool" in etype else ""

            row = (
                etype, now.isoformat()[:23]+"Z",
                random.choice(emails), str(uuid.uuid4()),
                model, round(cost, 5),
                random.randint(50, 1500) if model else 0,
                random.randint(20, 600)  if model else 0,
                random.randint(0, 60000) if model else 0,
                random.randint(300, 18000),
                tool,
                random.choice(["accept","accept","accept","reject"]) if etype=="claude_code.tool_decision" else "",
                random.choice(["true","true","true","false"]) if etype=="claude_code.tool_result" else "",
                random.randint(50, 4000) if etype=="claude_code.user_prompt" else 0,
                random.choice(["vscode","cursor","pycharm","iTerm2"]),
                now.hour, now.strftime("%Y-%m-%d"), DAYS[now.weekday()],
            )
            conn.execute(INSERT, row)
            conn.commit()
            total += 1

            if total % 50 == 0:
                elapsed = time.time() - t0
                print(f"   {total:,} events  |  {total/elapsed:.1f}/s  |  {duration-elapsed:.0f}s remaining")
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        conn.close()

    print(f"✓  Done. {total:,} live events added.")

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Stream live events into analytics DB")
    p.add_argument("--rate",     type=int, default=5,  help="Events per second")
    p.add_argument("--duration", type=int, default=30, help="Seconds to run")
    args = p.parse_args()
    simulate(args.rate, args.duration)
