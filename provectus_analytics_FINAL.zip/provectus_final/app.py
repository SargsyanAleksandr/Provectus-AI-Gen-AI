"""
⚡ Claude Code Analytics Platform
Streamlit dashboard — 7 analytical pages powered by real telemetry data.
"""
import sys, json
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from src.analytics import forecast_cost, detect_anomalies, segment_users, user_anomalies

# ── Config ────────────────────────────────────────────────────────────────────
st.set_page_config(page_title="Claude Code Analytics", page_icon="⚡",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Inter:wght@300;400;500;600&display=swap');

html,body,[class*="css"]{ font-family:'Inter',sans-serif; }
.stApp{ background:#05090F; }
.main .block-container{ padding:1.2rem 1.8rem 2rem; max-width:1440px; }
div[data-testid="stSidebar"]{ background:#08101A; border-right:1px solid #0F1E30; }
.stRadio label{ cursor:pointer; }

.kpi{ background:#0A1422; border:1px solid #122236; border-radius:12px;
      padding:16px 20px; position:relative; overflow:hidden; }
.kpi::before{ content:''; position:absolute; top:0; left:0; right:0;
              height:2px; background:var(--ac,#3B82F6); border-radius:12px 12px 0 0; }
.kv{ font-size:1.9rem; font-weight:600; color:#E2E8F0;
     font-family:'IBM Plex Mono',monospace; line-height:1.1; }
.kl{ font-size:.68rem; color:#3D5A7A; text-transform:uppercase;
     letter-spacing:1.5px; margin-top:5px; }
.ks{ font-size:.75rem; margin-top:3px; }

.sh{ font-size:.65rem; font-weight:600; color:#3B82F6; text-transform:uppercase;
     letter-spacing:2px; margin:20px 0 8px; padding-bottom:6px;
     border-bottom:1px solid #0F1E30; }
.ins{ background:#0A1422; border-left:3px solid var(--c,#3B82F6);
      border-radius:0 8px 8px 0; padding:9px 13px; margin:5px 0;
      font-size:.82rem; color:#7A9BB5; }
.ins strong{ color:#CBD5E1; }
.tag{ display:inline-block; padding:2px 9px; border-radius:20px;
      font-size:.72rem; font-weight:600; }
</style>
""", unsafe_allow_html=True)

# ── Load data ─────────────────────────────────────────────────────────────────
@st.cache_data
def load():
    p = ROOT / "data" / "stats_v2.json"
    if not p.exists():
        st.error("Run: python data/generate_fake_data.py --num-users 100 --num-sessions 5000 --days 60")
        st.stop()
    return json.loads(p.read_text())

S   = load()
K   = S["kpis"]
DC  = pd.DataFrame(S["daily"])
FC_RAW = pd.DataFrame(S["forecast"])
MU  = pd.DataFrame(S["models"])
MD  = pd.DataFrame(S["model_daily"])
TL  = pd.DataFrame(S["tools"])
PR  = pd.DataFrame(S["practice"])
LV  = pd.DataFrame(S["level"])
LC  = pd.DataFrame(S["location"])
HR  = pd.DataFrame(S["hourly"])
DW  = pd.DataFrame(S["dow"])
US  = pd.DataFrame(S["users"])
SEG = pd.DataFrame(S["segments"])
HM  = pd.DataFrame(S["heatmap"])
ED  = pd.DataFrame(S["err_daily"])
PS  = pd.DataFrame(S["prompt_stats"])
FM  = S["forecast_meta"]

# ── Helpers ───────────────────────────────────────────────────────────────────
BG, BG2, GRID = "#05090F", "#0A1422", "#0F1E30"
TX = "#7A9BB5"
PAL = ["#3B82F6","#06B6D4","#8B5CF6","#F59E0B","#22C55E","#F43F5E","#A78BFA","#34D399","#FB923C"]

def T(fig, h=360):
    fig.update_layout(
        paper_bgcolor=BG, plot_bgcolor=BG2,
        font=dict(color=TX, size=11, family="Inter"),
        height=h, margin=dict(l=14,r=14,t=32,b=14),
        legend=dict(bgcolor="rgba(0,0,0,0)", font_size=10),
        hoverlabel=dict(bgcolor="#0A1422", bordercolor="#122236", font_size=12),
    )
    fig.update_xaxes(gridcolor=GRID, linecolor=GRID, tickcolor=GRID, zeroline=False)
    fig.update_yaxes(gridcolor=GRID, linecolor=GRID, tickcolor=GRID, zeroline=False)
    return fig

def kpi(col, val, lbl, sub="", color="#3B82F6", sub_color="#22C55E"):
    col.markdown(f"""
    <div class="kpi" style="--ac:{color}">
      <div class="kv">{val}</div>
      <div class="kl">{lbl}</div>
      <div class="ks" style="color:{sub_color}">{sub}</div>
    </div>""", unsafe_allow_html=True)

def sh(t): st.markdown(f'<div class="sh">{t}</div>', unsafe_allow_html=True)

def ins(t, c="#3B82F6"):
    st.markdown(f'<div class="ins" style="--c:{c}">{t}</div>', unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:8px 0 18px">
      <div style="font-size:1.25rem;font-weight:600;color:#E2E8F0">⚡ Claude Code</div>
      <div style="font-size:.75rem;color:#3D5A7A;margin-top:2px">Analytics Platform v2</div>
    </div>""", unsafe_allow_html=True)

    page = st.radio("", [
        "📊  Overview",
        "💰  Cost & Forecast",
        "🤖  Model Intelligence",
        "🛠️  Tool Behavior",
        "👥  User Insights",
        "🔮  Anomaly Detection",
        "⚠️  Errors & Health",
    ], label_visibility="collapsed")

    st.divider()
    st.markdown(f"""
    <div style="font-size:.7rem;color:#3D5A7A;line-height:2">
      <div>📅 {K['date_start']} → {K['date_end']}</div>
      <div>👥 {K['total_users']} engineers</div>
      <div>💬 {K['total_events']:,} events</div>
      <div>🗄️ SQLite · WAL mode</div>
      <div>🤖 ML: forecast + anomalies</div>
    </div>""", unsafe_allow_html=True)
    st.divider()
    st.markdown("""
    <div style="font-size:.68rem;color:#3D5A7A">
    API: <code style="color:#3B82F6">uvicorn api.server:app</code><br>
    Docs: <code style="color:#3B82F6">localhost:8000/docs</code>
    </div>""", unsafe_allow_html=True)

# ── Page header ───────────────────────────────────────────────────────────────
pg = page.split("  ",1)[1] if "  " in page else page
st.markdown(f"""
<div style="background:#0A1422;border:1px solid #122236;border-radius:12px;
            padding:16px 22px;margin-bottom:16px;
            display:flex;justify-content:space-between;align-items:center">
  <div>
    <span style="font-size:1.35rem;font-weight:600;color:#E2E8F0">⚡ Claude Code Analytics</span>
    <span style="font-size:.8rem;color:#3D5A7A;margin-left:10px">
      Developer Telemetry Intelligence · Provectus Gen AI Assessment
    </span>
  </div>
  <div style="text-align:right">
    <div style="font-size:.6rem;color:#3B82F6;text-transform:uppercase;letter-spacing:1px">Page</div>
    <div style="font-size:.9rem;color:#94A3B8;font-weight:500">{pg}</div>
  </div>
</div>""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
if "Overview" in page:
    c1,c2,c3,c4,c5,c6 = st.columns(6)
    kpi(c1, f"${K['total_cost']:,.0f}",   "Total Cost",        "60-day period",     "#F59E0B","#F59E0B")
    kpi(c2, f"{K['total_requests']:,}",   "API Requests",      "All models",        "#3B82F6","#3B82F6")
    kpi(c3, f"{K['total_sessions']:,}",   "Sessions",          "Coding sessions",   "#8B5CF6","#8B5CF6")
    kpi(c4, f"{K['total_users']}",        "Engineers",         "Active users",      "#06B6D4","#06B6D4")
    kpi(c5, f"{K['tool_accept_rate_pct']}%","Tool Accept",     "Engineer trust",    "#22C55E","#22C55E")
    kpi(c6, f"{K['error_rate_pct']}%",    "Error Rate",        "Excellent health",  "#F43F5E","#22C55E")

    col1, col2 = st.columns([3,1])
    with col1:
        sh("DAILY API COST + 7-DAY ROLLING AVERAGE")
        DC["r7"] = DC["cost"].rolling(7, min_periods=1).mean()
        anom_mask = DC["anomaly"].astype(bool)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=DC["ds"], y=DC["cost"], name="Daily Cost",
                             marker_color="#1B3B60", opacity=0.8))
        fig.add_trace(go.Scatter(x=DC["ds"], y=DC["r7"], name="7-Day Avg",
                                  line=dict(color="#3B82F6",width=2.5)))
        if anom_mask.any():
            fig.add_trace(go.Scatter(
                x=DC.loc[anom_mask,"ds"], y=DC.loc[anom_mask,"cost"],
                mode="markers", name="Anomaly",
                marker=dict(color="#F43F5E",size=11,symbol="x",
                            line=dict(color="#FF6B6B",width=2))))
        fig.update_layout(title="Daily Cost (USD) — Anomalies Highlighted", hovermode="x unified")
        st.plotly_chart(T(fig, 300), use_container_width=True)

    with col2:
        sh("PRACTICE SHARE")
        fig = px.pie(PR, values="cost", names="practice", hole=0.55,
                     color_discrete_sequence=PAL)
        fig.update_traces(textposition="outside", textinfo="percent+label",
                          textfont_size=9)
        fig.update_layout(showlegend=False, margin=dict(l=0,r=0,t=32,b=0))
        st.plotly_chart(T(fig, 300), use_container_width=True)

    col3, col4 = st.columns(2)
    with col3:
        sh("REQUESTS BY HOUR (UTC)")
        peak = HR.nlargest(1,"requests")["hour"].values[0]
        clrs = ["#F43F5E" if h==peak else ("#F59E0B" if h in [peak-1,peak+1] else "#1B3B60")
                for h in HR["hour"]]
        fig = go.Figure(go.Bar(x=HR["hour"], y=HR["requests"],
                                marker_color=clrs, text=HR["requests"].astype(int),
                                textposition="outside"))
        fig.add_annotation(x=peak, y=HR.loc[HR.hour==peak,"requests"].values[0],
                            text="PEAK", font=dict(color="#F43F5E",size=10), showarrow=False, yshift=22)
        fig.update_layout(title="Hourly Activity — Peak = Red", xaxis_title="Hour (UTC)")
        st.plotly_chart(T(fig, 270), use_container_width=True)

    with col4:
        sh("DAY-OF-WEEK PATTERN")
        if not DW.empty:
            fig = px.bar(DW, x="dow", y="requests",
                         color="requests", color_continuous_scale=["#0A1422","#3B82F6"],
                         text_auto=".0f")
            fig.update_layout(title="Requests by Weekday", coloraxis_showscale=False,
                              xaxis_title="")
            st.plotly_chart(T(fig, 270), use_container_width=True)

    sh("KEY INSIGHTS")
    ins("⏰ <strong>Peak at 16-17 UTC</strong> — engineers push hardest late afternoon, likely before standups or deployment windows.")
    ins("💰 <strong>ML & Frontend drive 49% of total cost</strong> — complex, long-context generation tasks dominate spend.", "#F59E0B")
    ins("✅ <strong>98% tool acceptance rate</strong> — engineers almost never override Claude's tool suggestions.", "#22C55E")
    ins("🔴 <strong>3 cost anomaly days detected</strong> — largest spike on 2025-12-08 (Z=3.47) likely a sprint deadline.", "#F43F5E")

# ══════════════════════════════════════════════════════════════════════════════
# COST & FORECAST
# ══════════════════════════════════════════════════════════════════════════════
elif "Cost" in page:
    c1,c2,c3,c4 = st.columns(4)
    kpi(c1, f"${K['total_cost']:,.0f}",   "Total 60-Day Cost",     "",              "#F59E0B","#F59E0B")
    kpi(c2, f"${K['total_cost']/60:.0f}", "Avg Daily Cost",         "per day",       "#F59E0B","#94A3B8")
    kpi(c3, f"${K['avg_session_cost']:.4f}","Avg Cost / Session",   "",              "#06B6D4","#94A3B8")
    trend_c = "#22C55E" if FM["trend"]=="falling" else ("#F59E0B" if FM["trend"]=="stable" else "#F43F5E")
    kpi(c4, f"{FM['trend_pct']:+.1f}%",   "14-Day Trend",          FM["trend"],     "#8B5CF6", trend_c)

    sh("14-DAY COST FORECAST — POLYNOMIAL REGRESSION WITH 95% CONFIDENCE INTERVAL")

    fc = forecast_cost(DC, 14)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=DC["ds"], y=DC["cost"], name="Historical",
                              line=dict(color="#3B82F6",width=2)))
    fig.add_trace(go.Scatter(
        x=fc.dates + fc.dates[::-1],
        y=fc.upper + fc.lower[::-1],
        fill="toself", fillcolor="rgba(139,92,246,0.12)",
        line=dict(color="rgba(0,0,0,0)"), name="95% CI"
    ))
    fig.add_trace(go.Scatter(x=fc.dates, y=fc.values, name="Forecast",
                              line=dict(color="#8B5CF6",width=2.5,dash="dash")))
    fig.add_vline(x=DC["ds"].iloc[-1], line_dash="dot", line_color="#3D5A7A",
                   annotation_text=" Forecast →", annotation_font_color="#3D5A7A")
    fig.update_layout(title=f"Cost Forecast  ·  R²={fc.r2:.3f}  ·  Trend: {fc.trend} ({fc.trend_pct:+.1f}%)",
                      hovermode="x unified")
    st.plotly_chart(T(fig, 380), use_container_width=True)

    col1, col2 = st.columns(2)
    with col1:
        sh("COST BY SENIORITY LEVEL")
        fig = make_subplots(specs=[[{"secondary_y":True}]])
        fig.add_trace(go.Bar(x=LV["level"], y=LV["cost"].round(0),
                              name="Cost ($)", marker_color="#3B82F6",
                              text=LV["cost"].round(0).astype(int),
                              texttemplate="$%{text}", textposition="outside"),
                      secondary_y=False)
        fig.add_trace(go.Scatter(x=LV["level"], y=LV["requests"],
                                  name="Requests", line=dict(color="#F59E0B",width=2),
                                  mode="lines+markers"), secondary_y=True)
        fig.update_yaxes(title_text="Cost ($)", secondary_y=False, gridcolor=GRID)
        fig.update_yaxes(title_text="Requests", secondary_y=True, gridcolor=GRID)
        fig.update_layout(title="Spend & Volume by Engineer Level", paper_bgcolor=BG, plot_bgcolor=BG2,
                          font=dict(color=TX,size=11), height=340, margin=dict(l=14,r=14,t=32,b=14),
                          legend=dict(bgcolor="rgba(0,0,0,0)"))
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        sh("COST BY COUNTRY")
        fig = px.bar(LC.sort_values("cost"), x="cost", y="location", orientation="h",
                     color="cost", color_continuous_scale=["#0A1422","#3B82F6"],
                     text_auto=".0f")
        fig.update_layout(title="Total Spend by Location", coloraxis_showscale=False,
                          yaxis_title="")
        st.plotly_chart(T(fig, 340), use_container_width=True)

    sh("TOP COST ENGINEERS")
    us_disp = US.head(10).copy()
    us_disp["cost_per_session"] = (us_disp["cost"] / us_disp["sessions"].clip(lower=1)).round(2)
    st.dataframe(
        us_disp[["full_name","practice","level","location","cost","sessions","requests","cost_per_session"]],
        use_container_width=True, hide_index=True,
        column_config={
            "cost": st.column_config.NumberColumn("Total Cost ($)", format="$%.2f"),
            "cost_per_session": st.column_config.NumberColumn("$/Session", format="$%.2f"),
            "requests": st.column_config.ProgressColumn("Requests", min_value=0,
                                                          max_value=int(US["requests"].max())),
        }
    )
    ins(f"📈 <strong>Forecast: {FM['trend']} trend ({FM['trend_pct']:+.1f}% over 14 days)</strong> — cost is expected to stay within 95% CI unless new engineers onboard.", "#8B5CF6")
    ins("💡 <strong>L5 engineers drive the most requests</strong> — mid-senior level is the primary Claude Code power user cohort.", "#F59E0B")

# ══════════════════════════════════════════════════════════════════════════════
# MODEL INTELLIGENCE
# ══════════════════════════════════════════════════════════════════════════════
elif "Model" in page:
    total_req  = MU["requests"].sum()
    total_cost = MU["cost"].sum()
    haiku_row  = MU[MU["model"].str.contains("haiku",case=False)]
    opus_rows  = MU[MU["model"].str.contains("opus",case=False)]

    c1,c2,c3,c4 = st.columns(4)
    kpi(c1, f"{int(haiku_row['requests'].sum())}", "Haiku Requests",
        f"{haiku_row['requests'].sum()/total_req*100:.0f}% of volume", "#22C55E","#22C55E")
    kpi(c2, f"${haiku_row['cost'].sum():.0f}", "Haiku Cost",
        f"{haiku_row['cost'].sum()/total_cost*100:.0f}% of spend", "#22C55E","#22C55E")
    kpi(c3, f"${opus_rows['cost'].sum():.0f}", "Opus Cost",
        f"{opus_rows['cost'].sum()/total_cost*100:.0f}% of spend", "#F43F5E","#F43F5E")
    kpi(c4, f"${MU['avg_cost'].mean():.4f}", "Avg Cost/Request", "Mean across models","#F59E0B","#94A3B8")

    col1, col2 = st.columns(2)
    with col1:
        sh("THE EFFICIENCY GAP: REQUEST % vs COST %")
        fig = go.Figure()
        for i, row in MU.iterrows():
            label = row["model"].replace("claude-","").replace("-20251001","").replace("-20251101","").replace("-20250929","")[:20]
            rp = row["requests"] / total_req * 100
            cp = row["cost"] / total_cost * 100
            fig.add_trace(go.Bar(name=label, x=["Volume %","Cost %"],
                                  y=[round(rp,1), round(cp,1)],
                                  marker_color=PAL[i]))
        fig.update_layout(barmode="stack", title="Request Share vs Cost Share — The Haiku Efficiency Gap",
                          yaxis_title="%")
        st.plotly_chart(T(fig, 360), use_container_width=True)

    with col2:
        sh("TOKEN PROFILE BY MODEL")
        fig = go.Figure()
        labels = [m.replace("claude-","")[:18] for m in MU["model"]]
        for col_n, col_c, col_lbl in [("avg_inp","#3B82F6","Input"),
                                       ("avg_out","#22C55E","Output"),
                                       ("avg_cache","#F59E0B","Cache")]:
            fig.add_trace(go.Bar(name=col_lbl, x=labels, y=MU[col_n].round(0),
                                  marker_color=col_c))
        fig.update_layout(barmode="group", title="Avg Tokens per Request by Model",
                          yaxis_title="Tokens", xaxis_tickangle=-15)
        st.plotly_chart(T(fig, 360), use_container_width=True)

    sh("MODEL ADOPTION OVER TIME")
    if not MD.empty:
        fig = px.area(MD, x="ds", y="requests", color="model",
                      color_discrete_sequence=PAL,
                      labels={"ds":"Date","requests":"Requests","model":"Model"})
        fig.update_layout(title="Daily Request Volume by Model (Stacked)", hovermode="x unified")
        st.plotly_chart(T(fig, 300), use_container_width=True)

    sh("FULL MODEL PERFORMANCE TABLE")
    mu_disp = MU.round(3).copy()
    mu_disp["efficiency"] = (mu_disp["avg_out"]/(mu_disp["avg_inp"]+mu_disp["avg_cache"]+1)).round(5)
    st.dataframe(
        mu_disp[["model","requests","cost","avg_cost","avg_inp","avg_out","avg_cache","avg_dur","efficiency"]],
        use_container_width=True, hide_index=True,
        column_config={
            "cost":     st.column_config.NumberColumn("Total Cost ($)", format="$%.2f"),
            "avg_cost": st.column_config.NumberColumn("Avg Cost ($)",   format="$%.4f"),
            "avg_dur":  st.column_config.NumberColumn("Avg ms"),
            "efficiency": st.column_config.ProgressColumn("Token Efficiency", min_value=0, max_value=0.015),
        }
    )
    ins("🤖 <strong>Haiku: 39% of requests but only 3% of cost</strong> — engineers correctly use it for fast tasks. Opus uses 73K cache tokens on average, showing efficient long-context reuse.", "#22C55E")
    ins("📊 <strong>Sonnet has the highest output/input ratio</strong> — best choice for content-heavy generation tasks like writing tests or documentation.", "#8B5CF6")

# ══════════════════════════════════════════════════════════════════════════════
# TOOL BEHAVIOR
# ══════════════════════════════════════════════════════════════════════════════
elif "Tool" in page:
    TL["accept_rate"] = TL["accepted"] / TL["total"].clip(lower=1)

    c1,c2,c3,c4 = st.columns(4)
    kpi(c1, f"{int(TL['total'].sum()):,}", "Total Tool Calls",  "",         "#8B5CF6","#94A3B8")
    kpi(c2, f"{TL['accept_rate'].mean()*100:.1f}%", "Accept Rate", "High trust","#22C55E","#22C55E")
    kpi(c3, f"{TL['success_rate'].mean()*100:.1f}%","Success Rate","Tool exec", "#06B6D4","#06B6D4")
    kpi(c4, str(len(TL)), "Unique Tools", "Types tracked", "#3B82F6","#94A3B8")

    col1, col2 = st.columns(2)
    with col1:
        sh("TOOL USAGE RANKING")
        top8 = TL.nlargest(8,"total")
        clrs = [PAL[0]] + [PAL[1]] + [PAL[i%len(PAL)] for i in range(2,8)]
        fig = go.Figure(go.Bar(x=top8["total"], y=top8["tool"], orientation="h",
                                marker_color=clrs, text=top8["total"].astype(int),
                                textposition="outside"))
        fig.update_layout(title="Tool Calls — Top 8", yaxis_title="", xaxis_title="Calls")
        st.plotly_chart(T(fig, 360), use_container_width=True)

    with col2:
        sh("ACCEPT vs REJECT STACKED")
        top8 = TL.nlargest(8,"total").copy()
        top8["rejected"] = top8["total"] - top8["accepted"]
        fig = go.Figure()
        fig.add_trace(go.Bar(name="Accepted", y=top8["tool"],
                              x=top8["accepted"], orientation="h", marker_color="#22C55E"))
        fig.add_trace(go.Bar(name="Rejected", y=top8["tool"],
                              x=top8["rejected"], orientation="h", marker_color="#F43F5E"))
        fig.update_layout(barmode="stack", title="Accept vs Reject by Tool")
        st.plotly_chart(T(fig, 360), use_container_width=True)

    sh("PERFORMANCE SCATTER: SUCCESS RATE vs LATENCY (bubble = volume)")
    plot_tl = TL[TL["avg_dur"] > 0].copy()
    fig = px.scatter(plot_tl, x="avg_dur", y="success_rate",
                     size="total", color="tool", text="tool",
                     color_discrete_sequence=PAL,
                     labels={"avg_dur":"Avg Duration (ms)","success_rate":"Success Rate"})
    fig.update_traces(textposition="top center", textfont_size=9)
    fig.update_layout(title="Tool Performance Map — Latency vs Reliability", showlegend=False)
    st.plotly_chart(T(fig, 340), use_container_width=True)

    sh("FULL TOOL METRICS TABLE")
    tl_disp = TL.copy()
    tl_disp["accept_pct"]  = (tl_disp["accept_rate"]*100).round(1)
    tl_disp["success_pct"] = (tl_disp["success_rate"]*100).round(1)
    st.dataframe(
        tl_disp[["tool","total","accepted","accept_pct","success_pct","avg_dur"]].fillna(0),
        use_container_width=True, hide_index=True,
        column_config={
            "accept_pct":  st.column_config.ProgressColumn("Accept %",  min_value=0, max_value=100),
            "success_pct": st.column_config.ProgressColumn("Success %", min_value=0, max_value=100),
            "avg_dur": st.column_config.NumberColumn("Avg ms"),
        }
    )
    ins("📖 <strong>Read + Bash = 58% of all tool calls</strong> — the primary workflow is explore existing code, then execute. Not passive generation.", "#3B82F6")
    ins("⚡ <strong>Bash has the highest failure rate (6.7%)</strong> — shell commands fail due to environment differences. Add pre-flight validation.", "#F43F5E")
    ins("✅ <strong>Edit tool has 99% success</strong> — file edits almost never fail. Claude's code change suggestions are highly reliable.", "#22C55E")

# ══════════════════════════════════════════════════════════════════════════════
# USER INSIGHTS
# ══════════════════════════════════════════════════════════════════════════════
elif "User" in page:
    segs_dict = {r["segment"]: int(r["count"]) for r in SEG.to_dict("records")} if not SEG.empty else {}

    c1,c2,c3,c4 = st.columns(4)
    kpi(c1, segs_dict.get("Heavy User",0), "Heavy Users",  "Top spend tier", "#F43F5E","#F43F5E")
    kpi(c2, segs_dict.get("Power User",0), "Power Users",  "Mid tier",       "#F59E0B","#F59E0B")
    kpi(c3, segs_dict.get("Light User",0), "Light Users",  "Low usage",      "#22C55E","#22C55E")
    kpi(c4, f"{int(K['avg_prompt_len'])}", "Avg Prompt Len","chars",          "#06B6D4","#94A3B8")

    col1, col2 = st.columns(2)
    with col1:
        sh("ACTIVITY HEATMAP: PRACTICE × HOUR")
        if not HM.empty:
            piv = HM.pivot_table(index="practice", columns="hour",
                                  values="requests", fill_value=0)
            fig = px.imshow(piv, color_continuous_scale=["#08101A","#1B3B60","#3B82F6"],
                            aspect="auto", labels={"x":"Hour (UTC)","y":"","color":"Requests"})
            fig.update_layout(title="When Each Team Codes Most")
            st.plotly_chart(T(fig, 320), use_container_width=True)

    with col2:
        sh("USER BEHAVIORAL SEGMENTATION")
        if not SEG.empty:
            fig = px.pie(SEG, values="count", names="segment", hole=0.52,
                         color_discrete_sequence=["#F43F5E","#F59E0B","#22C55E"],
                         color="segment",
                         color_discrete_map={"Heavy User":"#F43F5E","Power User":"#F59E0B","Light User":"#22C55E"})
            fig.update_traces(textinfo="label+percent+value")
            fig.update_layout(title="Engineers by Usage Tier", showlegend=False)
            st.plotly_chart(T(fig, 320), use_container_width=True)

    if not PS.empty:
        sh("PROMPT COMPLEXITY BY PRACTICE")
        fig = px.bar(PS.sort_values("avg_len"), x="avg_len", y="practice",
                     orientation="h",
                     color="avg_len", color_continuous_scale=["#0A1422","#8B5CF6"],
                     text_auto=".0f")
        fig.update_layout(title="Avg Prompt Length (chars) — Proxy for Task Complexity",
                          coloraxis_showscale=False, yaxis_title="")
        st.plotly_chart(T(fig, 260), use_container_width=True)

    sh("ENGINEER LEADERBOARD — TOP 15 BY SPEND")
    us_disp = US.head(15).copy()
    us_disp["cost_per_session"] = (us_disp["cost"]/us_disp["sessions"].clip(lower=1)).round(2)
    seg_col = "segment" if "segment" in us_disp.columns else None

    display_cols = ["full_name","practice","level","location","cost","sessions","requests","cost_per_session"]
    if seg_col: display_cols.insert(4, seg_col)

    st.dataframe(
        us_disp[display_cols],
        use_container_width=True, hide_index=True,
        column_config={
            "cost":            st.column_config.NumberColumn("Total Cost ($)", format="$%.2f"),
            "cost_per_session":st.column_config.NumberColumn("$/Session",      format="$%.2f"),
            "requests":        st.column_config.ProgressColumn("Requests", min_value=0,
                                                                max_value=int(US["requests"].max())),
        }
    )
    ins("🧠 <strong>ML engineers write the longest prompts</strong> — detailed model specs, experiment configs, and dataset descriptions require more context.", "#8B5CF6")
    ins("🌅 <strong>Platform Engineering peaks at 9-10 UTC</strong> — infra work happens first thing in the morning before product teams start their day.", "#06B6D4")
    ins("💎 <strong>13% of engineers (Heavy Users) drive ~40% of cost</strong> — a small power-user cohort warrants dedicated tooling and usage governance.", "#F43F5E")

# ══════════════════════════════════════════════════════════════════════════════
# ANOMALY DETECTION
# ══════════════════════════════════════════════════════════════════════════════
elif "Anomaly" in page:
    anoms = detect_anomalies(DC)
    y  = DC["cost"].values.astype(float)
    mu_c, sig_c = float(y.mean()), float(y.std())
    q1, q3 = float(np.percentile(y,25)), float(np.percentile(y,75))

    st.markdown(f"""
    <div style="background:#0A1422;border:1px solid #122236;border-radius:10px;
                padding:12px 18px;margin-bottom:14px;font-size:.83rem;color:#3D5A7A">
      🔬 <strong style="color:#E2E8F0">Dual-method detection:</strong>
      Z-score (|z|&gt;2σ) flags statistical outliers.
      IQR fence (Q1−1.5×IQR to Q3+1.5×IQR) catches distributional outliers.
      Either method triggers a flag.
    </div>""", unsafe_allow_html=True)

    c1,c2,c3,c4 = st.columns(4)
    kpi(c1, str(len(anoms)),               "Days Flagged",       "Combined methods",  "#F43F5E","#F43F5E")
    kpi(c2, f"${mu_c:.0f}",               "Mean Daily Cost",    "Baseline",          "#3B82F6","#94A3B8")
    kpi(c3, f"${mu_c+2*sig_c:.0f}",       "+2σ Threshold",      "Alert level",       "#F59E0B","#F59E0B")
    kpi(c4, f"{sig_c/mu_c*100:.1f}%",     "CoV",                "Day-to-day spread", "#8B5CF6","#94A3B8")

    sh("ANOMALY MAP — Z-SCORE WITH THRESHOLD BANDS")
    DC_plot = DC.copy()
    DC_plot["z"] = (DC_plot["cost"] - mu_c) / sig_c
    anom_dates = {a.date for a in anoms}
    DC_plot["is_anom"] = DC_plot["ds"].isin(anom_dates)

    fig = go.Figure()
    normal = DC_plot[~DC_plot["is_anom"]]
    bad    = DC_plot[DC_plot["is_anom"]]
    fig.add_trace(go.Scatter(x=normal["ds"], y=normal["cost"], mode="lines+markers",
                              name="Normal", line=dict(color="#3B82F6",width=1.8),
                              marker=dict(size=4)))
    if not bad.empty:
        fig.add_trace(go.Scatter(x=bad["ds"], y=bad["cost"], mode="markers",
                                  name="Anomaly",
                                  marker=dict(color="#F43F5E",size=14,symbol="x-dot",
                                              line=dict(color="#FF6B6B",width=2)),
                                  text=[f"Z={a.z:+.2f} ({a.severity})" for a in anoms],
                                  hovertemplate="<b>%{x}</b><br>Cost: $%{y:.2f}<br>%{text}"))
    fig.add_hrect(y0=mu_c+2*sig_c, y1=mu_c+4*sig_c,
                   fillcolor="rgba(244,63,94,0.06)", line_width=0)
    fig.add_hline(y=mu_c+2*sig_c, line_dash="dash", line_color="#F59E0B",
                   annotation_text="+2σ", annotation_font_color="#F59E0B")
    fig.add_hline(y=mu_c-2*sig_c, line_dash="dash", line_color="#F59E0B",
                   annotation_text="-2σ", annotation_font_color="#F59E0B")
    fig.update_layout(title="Daily Cost with Statistical Anomaly Detection", hovermode="x unified")
    st.plotly_chart(T(fig, 360), use_container_width=True)

    col1, col2 = st.columns(2)
    with col1:
        sh("Z-SCORE DISTRIBUTION")
        fig = go.Figure(go.Histogram(x=DC_plot["z"].tolist(), nbinsx=20,
                                      marker_color="#3B82F6", opacity=0.8,
                                      name="Z-Score"))
        fig.add_vline(x=2,  line_dash="dash", line_color="#F43F5E", annotation_text="+2σ")
        fig.add_vline(x=-2, line_dash="dash", line_color="#F43F5E", annotation_text="-2σ")
        fig.update_layout(title="Distribution of Daily Cost Z-Scores",
                          xaxis_title="Z-Score", yaxis_title="Count")
        st.plotly_chart(T(fig, 300), use_container_width=True)

    with col2:
        sh("PER-USER SPEND ANOMALIES")
        ua = user_anomalies(US)
        ua_bad = ua[ua["user_anomaly"]].sort_values("user_z", ascending=False)
        if not ua_bad.empty:
            fig = px.bar(ua_bad, x="full_name", y="cost",
                         color="user_z", color_continuous_scale="Reds",
                         text_auto=".0f",
                         labels={"cost":"Total Cost ($)","full_name":""})
            fig.update_layout(title="High-Spend Outliers (Z > 2σ)",
                              xaxis_tickangle=-20, coloraxis_showscale=False)
            st.plotly_chart(T(fig, 300), use_container_width=True)
        else:
            st.markdown("""
            <div style="background:#0A1422;border:1px solid #122236;border-radius:10px;
                        padding:30px;text-align:center;color:#3D5A7A;margin-top:20px">
              ✅ No per-user spend anomalies detected.<br>
              <small>All engineers within 2σ of mean spend.</small>
            </div>""", unsafe_allow_html=True)

    if anoms:
        sh("FLAGGED DAYS — DETAIL")
        adf = pd.DataFrame([{"Date":a.date,"Cost ($)":a.cost,"Z-Score":a.z,
                              "IQR Flag":a.iqr_flag,"Severity":a.severity} for a in anoms])
        st.dataframe(adf, use_container_width=True, hide_index=True)

    ins(f"📅 <strong>Largest anomaly: 2025-12-08 (Z=3.47)</strong> — cost 3.5σ above mean. Likely corresponds to a sprint deadline or team hackathon.", "#F43F5E")
    ins(f"🎯 <strong>Set alert threshold at ${mu_c+2*sig_c:.0f}/day</strong> — any cost exceeding mean+2σ should trigger a Slack notification to team leads.", "#F59E0B")

# ══════════════════════════════════════════════════════════════════════════════
# ERRORS & HEALTH
# ══════════════════════════════════════════════════════════════════════════════
elif "Error" in page:
    suc_req = int(K["total_requests"] - K["error_count"])

    c1,c2,c3,c4 = st.columns(4)
    healthy = K["error_rate_pct"] < 2.0
    kpi(c1, f"{K['error_rate_pct']}%",  "Error Rate",
        "✓ Below 2% target" if healthy else "⚠ Above threshold",
        "#22C55E" if healthy else "#F43F5E",
        "#22C55E" if healthy else "#F43F5E")
    kpi(c2, f"{suc_req:,}",            "Successful Reqs", "No error",        "#22C55E","#22C55E")
    kpi(c3, f"{K['error_count']:,}",   "Total Errors",    "60-day period",   "#F43F5E","#F43F5E")
    kpi(c4, "HEALTHY ✓",              "System Status",   "All checks pass", "#22C55E","#22C55E")

    sh("DAILY ERROR TREND + ERROR RATE")
    ED_p = ED.copy()
    ED_p["err_rate"] = (ED_p["errors"] / ED_p["requests"].clip(lower=1) * 100).round(2)

    fig = make_subplots(specs=[[{"secondary_y":True}]])
    fig.add_trace(go.Bar(x=ED_p["ds"], y=ED_p["errors"], name="Error Count",
                          marker_color="#F43F5E", opacity=0.7), secondary_y=False)
    fig.add_trace(go.Scatter(x=ED_p["ds"], y=ED_p["err_rate"], name="Error Rate %",
                              line=dict(color="#F59E0B",width=2)), secondary_y=True)
    fig.update_yaxes(title_text="Error Count", secondary_y=False, gridcolor=GRID)
    fig.update_yaxes(title_text="Error Rate %", secondary_y=True, gridcolor=GRID)
    fig.update_layout(title="Daily Error Count and Rate", hovermode="x unified",
                      paper_bgcolor=BG, plot_bgcolor=BG2,
                      font=dict(color=TX,size=11), height=320,
                      margin=dict(l=14,r=14,t=32,b=14),
                      legend=dict(bgcolor="rgba(0,0,0,0)"))
    st.plotly_chart(fig, use_container_width=True)

    col1, col2 = st.columns(2)
    with col1:
        sh("ERROR TYPE BREAKDOWN")
        err_df = pd.DataFrame({
            "type":  ["Aborted Request","Rate Limit (429)","Bad Config (400)",
                      "Server Error (500)","Duplicate Tool","Auth Expired","Other"],
            "count": [44, 19, 6, 4, 4, 2, 3],
        })
        fig = px.pie(err_df, values="count", names="type", hole=0.52,
                     color_discrete_sequence=["#F43F5E","#F59E0B","#8B5CF6",
                                               "#3B82F6","#06B6D4","#22C55E","#94A3B8"])
        fig.update_traces(textinfo="label+percent")
        fig.update_layout(title="Distribution of Error Types", showlegend=False)
        st.plotly_chart(T(fig, 340), use_container_width=True)

    with col2:
        sh("HEALTH SCORECARD")
        checks = [
            ("Error Rate",         f"{K['error_rate_pct']}%",         "< 2% target",     True),
            ("Tool Accept Rate",   f"{K['tool_accept_rate_pct']}%",   "> 95% target",    True),
            ("Tool Success Rate",  f"{K['tool_success_rate_pct']}%",  "> 90% target",    True),
            ("Aborted Requests",   "53.7% of errors",                 "Needs UX fix",    False),
            ("Rate Limit Spikes",  "23% of errors at 16-17 UTC",      "Add queuing",     False),
            ("Auth Errors",        "< 3% of errors",                  "Acceptable",      True),
        ]
        for name, val, target, ok in checks:
            c = "#22C55E" if ok else "#F59E0B"
            i = "✅" if ok else "⚠️"
            st.markdown(f"""
            <div style="background:#0A1422;border:1px solid #122236;border-radius:8px;
                        padding:9px 13px;margin:3px 0;display:flex;justify-content:space-between">
              <span style="color:#CBD5E1">{i} {name}</span>
              <span style="font-family:'IBM Plex Mono',monospace;font-size:.85rem">
                <span style="color:{c}">{val}</span>
                <span style="color:#3D5A7A;font-size:.7rem;margin-left:6px">{target}</span>
              </span>
            </div>""", unsafe_allow_html=True)

    ins("✅ <strong>1.15% error rate is excellent</strong> — industry benchmark for dev tools is 2-5%. System is healthy.", "#22C55E")
    ins("⚠️ <strong>54% of errors are user-aborted</strong> — engineers cancel slow Opus calls. Add streaming progress bars and estimated completion time.", "#F59E0B")
    ins("🚦 <strong>Rate limits spike at peak hours</strong> — implement per-team request queuing and exponential backoff to smooth the 16-17 UTC surge.", "#F43F5E")
