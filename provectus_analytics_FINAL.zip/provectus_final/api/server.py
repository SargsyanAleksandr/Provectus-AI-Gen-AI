"""
Claude Code Analytics — REST API
15 endpoints covering all analytics.

Start: uvicorn api.server:app --port 8000 --reload
Docs:  http://localhost:8000/docs
"""
from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import json, sqlite3
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.analytics import forecast_cost, detect_anomalies, segment_users, user_anomalies
import pandas as pd

ROOT    = Path(__file__).parent.parent
STATS   = json.loads((ROOT / "data" / "stats_v2.json").read_text())
DB_PATH = ROOT / "data" / "analytics.db"

app = FastAPI(
    title="Claude Code Analytics API",
    description="""
## Claude Code Telemetry Analytics

REST API for programmatic access to developer usage analytics.

### Features
- Real-time KPI retrieval
- Cost forecasting with ML
- Anomaly detection (Z-score + IQR)
- User behavioral segmentation
- Tool performance metrics
    """,
    version="2.0.0",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def _get_db():
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/", tags=["Health"], summary="Root")
def root():
    return {"status": "ok", "service": "Claude Code Analytics API", "version": "2.0.0"}


@app.get("/api/health", tags=["Health"], summary="Health check")
def health():
    kpis = STATS["kpis"]
    return {
        "status": "healthy",
        "total_events": kpis["total_events"],
        "date_range": f"{kpis['date_start']} → {kpis['date_end']}",
    }


# ── Overview ──────────────────────────────────────────────────────────────────

@app.get("/api/kpis", tags=["Overview"], summary="Core KPIs")
def get_kpis():
    """Total cost, requests, sessions, users, error rate, tool accept rate."""
    return STATS["kpis"]


@app.get("/api/summary", tags=["Overview"], summary="Full analytics summary")
def get_summary():
    """All pre-computed analytics in one response."""
    return {k: STATS[k] for k in ["kpis","practice","models","tools","segments","forecast_meta"]}


# ── Cost ──────────────────────────────────────────────────────────────────────

@app.get("/api/cost/daily", tags=["Cost"], summary="Daily cost time series")
def get_daily_cost(days: int = Query(60, ge=1, le=365)):
    rows = STATS["daily"][-days:]
    return {"count": len(rows), "data": rows}


@app.get("/api/cost/forecast", tags=["Cost", "ML"], summary="14-day cost forecast")
def get_forecast(horizon: int = Query(14, ge=1, le=30)):
    """Polynomial regression with 95% confidence interval."""
    daily = pd.DataFrame(STATS["daily"])
    fc    = forecast_cost(daily, horizon)
    meta  = STATS["forecast_meta"]
    return {
        "horizon_days": horizon,
        "trend":        fc.trend,
        "trend_pct":    fc.trend_pct,
        "r_squared":    fc.r2,
        "resid_std":    fc.resid_std,
        "forecast": [
            {"date": d, "forecast": v, "upper": u, "lower": l}
            for d, v, u, l in zip(fc.dates, fc.values, fc.upper, fc.lower)
        ],
    }


@app.get("/api/cost/by-practice", tags=["Cost"])
def cost_by_practice():
    return STATS["practice"]


@app.get("/api/cost/by-level", tags=["Cost"])
def cost_by_level():
    return STATS["level"]


@app.get("/api/cost/by-location", tags=["Cost"])
def cost_by_location():
    return STATS["location"]


# ── Models ────────────────────────────────────────────────────────────────────

@app.get("/api/models", tags=["Models"], summary="Model performance stats")
def get_models():
    """Requests, cost, avg tokens, latency, efficiency score per model."""
    return STATS["models"]


@app.get("/api/models/daily", tags=["Models"], summary="Model adoption over time")
def get_model_daily():
    return STATS["model_daily"]


# ── Tools ─────────────────────────────────────────────────────────────────────

@app.get("/api/tools", tags=["Tools"], summary="Tool usage and performance")
def get_tools():
    """Accept rate, success rate, avg latency per tool."""
    return STATS["tools"]


# ── Users ─────────────────────────────────────────────────────────────────────

@app.get("/api/users/top", tags=["Users"], summary="Top engineers by spend")
def get_top_users(n: int = Query(10, ge=1, le=100)):
    return STATS["users"][:n]


@app.get("/api/users/segments", tags=["Users", "ML"], summary="Behavioral segmentation")
def get_segments():
    """Light / Power / Heavy User clusters + anomalous spenders."""
    return {
        "segments":       STATS["segments"],
        "user_anomalies": STATS["user_anomalies"],
    }


# ── Anomalies ─────────────────────────────────────────────────────────────────

@app.get("/api/anomalies", tags=["Anomalies", "ML"], summary="Cost anomaly detection")
def get_anomalies():
    """Dual-method detection: Z-score |z|>2 AND IQR fence method."""
    daily  = pd.DataFrame(STATS["daily"])
    anoms  = detect_anomalies(daily)
    return {
        "count": len(anoms),
        "method": "Z-score (|z|>2) + IQR (Q1-1.5×IQR, Q3+1.5×IQR)",
        "anomalies": [
            {"date": a.date, "cost": a.cost, "z_score": a.z,
             "iqr_flag": a.iqr_flag, "severity": a.severity}
            for a in anoms
        ],
    }


# ── Activity ──────────────────────────────────────────────────────────────────

@app.get("/api/activity/hourly", tags=["Activity"])
def get_hourly():
    return STATS["hourly"]


@app.get("/api/activity/heatmap", tags=["Activity"], summary="Practice × hour matrix")
def get_heatmap():
    return STATS["heatmap"]


@app.get("/api/activity/dow", tags=["Activity"], summary="Day-of-week pattern")
def get_dow():
    return STATS["dow"]


# ── Errors ────────────────────────────────────────────────────────────────────

@app.get("/api/errors/daily", tags=["Errors"], summary="Daily error trends")
def get_errors():
    return STATS["err_daily"]
